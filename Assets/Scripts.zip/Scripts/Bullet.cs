
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 30f;
    public float lifeTime = 3f;

    private Rigidbody rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Start()
    {
        if (rb == null)
        {
            Debug.LogError("Bullet needs a Rigidbody!", this);
            return;
        }

        rb.useGravity = false;
        rb.isKinematic = false;

        // Move in the direction the bullet faces.
        rb.velocity = transform.forward * speed;

        Destroy(gameObject, lifeTime);
    }
    public void SetOwner(GameObject owner)
    {
        Collider myCol = GetComponentInChildren<Collider>();
        if (myCol == null) return;

        foreach (Collider c in owner.GetComponentsInChildren<Collider>())
            Physics.IgnoreCollision(myCol, c);
    }   

    private void OnCollisionEnter(Collision collision)
    {
        Destroy(gameObject);
    }
}

