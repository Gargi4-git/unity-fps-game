
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class Enemy : MonoBehaviour
{
    public int health = 100;
    public GameObject bulletPrefab;
    public Transform bulletSpawnPoint;
    public GameObject weaponFlash;
    public float bloom;
    public float fireRate;
    public float lastShootTime = 0f;

    private Rigidbody rb;
    public Material HitMat;
    private Renderer rend;
    private Material originalMaterial;
    private NavMeshAgent agent;

    public int currentPointIndex = 0;
    public Vector3 currentTarget;
    public float positionThreshold = 1f;
    public float idleTime = 5f;
    public float attackDistance = 5f;
    public float maxVisionDistance = 20f;
    public float minChasingHealth = 30f;
    public AudioClip shootingSFX;

    public Transform[] patrolPoints;

    private float idleTimeCounter;
    private Transform playerTransform;
    private bool canSeePlayer;
    private Vector3 lastKnownPlayerPosition;

    public enum State
    {
        Idle,
        Patrolling,
        Chasing,
        Attacking
    }

    public State state = State.Idle;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        rend = GetComponentInChildren<Renderer>();
        agent = GetComponent<NavMeshAgent>();

        if (rend != null)
            originalMaterial = rend.material;

        if (agent == null)
        {
            Debug.LogError("Enemy needs a NavMeshAgent!", this);
            enabled = false;
            return;
        }

        GameObject playerObject = GameObject.FindWithTag("Player");

        if (playerObject == null)
        {
            Debug.LogError("No GameObject tagged Player was found!", this);
            enabled = false;
            return;
        }

        playerTransform = playerObject.transform;
        lastKnownPlayerPosition = playerTransform.position;

        GameObject patrolParent = GameObject.FindWithTag("PatrolPoint");

        if (patrolParent != null)
        {
            Transform[] allPoints =
                patrolParent.GetComponentsInChildren<Transform>();

            int count = 0;

            foreach (Transform point in allPoints)
            {
                if (point != patrolParent.transform)
                    count++;
            }

            patrolPoints = new Transform[count];
            int index = 0;

            foreach (Transform point in allPoints)
            {
                if (point != patrolParent.transform)
                {
                    patrolPoints[index] = point;
                    index++;
                }
            }
        }

        if (patrolPoints == null || patrolPoints.Length == 0)
        {
            Debug.LogWarning(
                "No patrol points found. Enemy cannot patrol.",
                this
            );
        }
        else
        {
            currentPointIndex = 0;
            currentTarget = patrolPoints[0].position;
            idleTimeCounter = idleTime;
        }
    }

    private void Update()
    {
        if (playerTransform == null || agent == null)
            return;

        LookForPlayer();

        switch (state)
        {
            case State.Idle:
                Idle();
                break;

            case State.Patrolling:
                Patrolling();
                break;

            case State.Chasing:
                Chasing();
                break;

            case State.Attacking:
                Attacking();
                break;
        }

        LookAtPlayer();
        SetLastKnownPlayerPosition();
    }

    private void LookForPlayer()
    {
        canSeePlayer = false;

        Vector3 origin = transform.position + Vector3.up;
        Vector3 target = playerTransform.position + Vector3.up * 0.5f;
        Vector3 direction = target - origin;

        if (direction.magnitude > maxVisionDistance)
            return;

        if (Physics.Raycast(
            origin,
            direction.normalized,
            out RaycastHit hit,
            maxVisionDistance))
        {
            if (hit.transform == playerTransform ||
                hit.transform.IsChildOf(playerTransform))
            {
                canSeePlayer = true;

                if (state != State.Attacking)
                    state = State.Chasing;
            }
        }
    }

    private void Idle()
    {
        agent.ResetPath();
        idleTimeCounter -= Time.deltaTime;

        if (idleTimeCounter <= 0f)
        {
            if (patrolPoints != null && patrolPoints.Length > 0)
                state = State.Patrolling;
        }
    }

    private void Patrolling()
    {
        if (patrolPoints == null || patrolPoints.Length == 0)
            return;

        if (Vector3.Distance(transform.position, currentTarget)
            < positionThreshold)
        {
            if (Random.Range(0, 100) < 10)
            {
                idleTimeCounter = idleTime;
                state = State.Idle;
                return;
            }

            currentPointIndex =
                (currentPointIndex + 1) % patrolPoints.Length;

            currentTarget = patrolPoints[currentPointIndex].position;
        }

        agent.SetDestination(currentTarget);
    }

    private void Chasing()
    {
        if (health < minChasingHealth)
        {
            state = State.Patrolling;
            return;
        }

        agent.SetDestination(lastKnownPlayerPosition);

        float distance = Vector3.Distance(
            transform.position,
            playerTransform.position
        );

        if (distance <= attackDistance && canSeePlayer)
        {
            state = State.Attacking;
        }
        else if (distance > maxVisionDistance && !canSeePlayer)
        {
            state = State.Patrolling;
        }
    }

    private void Attacking()
    {
        idleTimeCounter = idleTime;
        agent.ResetPath();
        Shoot();

        float distance = Vector3.Distance(
            transform.position,
            playerTransform.position
        );

        if (distance > attackDistance || !canSeePlayer)
        {
            state = health < minChasingHealth
                ? State.Patrolling
                : State.Chasing;
        }
    }

    private void LookAtPlayer()
    {
        if (!canSeePlayer)
            return;

        Vector3 target = playerTransform.position;
        target.y = transform.position.y;

        transform.LookAt(target);
    }

    private void SetLastKnownPlayerPosition()
    {
        if (canSeePlayer)
            lastKnownPlayerPosition = playerTransform.position;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!collision.gameObject.CompareTag("PlayerBullet"))
            return;

        health -= 10;

        if (health <= 0)
        {
            Die();
        }
        else if (rend != null && HitMat != null)
        {
            StopCoroutine(nameof(Blink));
            StartCoroutine(Blink());
        }
    }

    private IEnumerator Blink()
    {
        rend.material = HitMat;

        yield return new WaitForSeconds(0.1f);

        if (rend != null && originalMaterial != null)
            rend.material = originalMaterial;
    }

    private void Die()
    {
        if (rb != null)
            rb.freezeRotation = false;

        if (agent != null)
            agent.enabled = false;

        enabled = false;
    }

    private void Shoot()
    {
        if (Time.time > lastShootTime + fireRate)
        {
            Vector3 directionToPlayer =
                playerTransform.position - transform.position;

            directionToPlayer.Normalize();

            Quaternion bulletRotation =
                Quaternion.LookRotation(directionToPlayer);

            float maxInaccuracy = 10f;
            float currentInaccuracy = bloom * maxInaccuracy;

            float randomJaw = Random.Range(
                -currentInaccuracy,
                currentInaccuracy
            );

            float randomPitch = Random.Range(
                -currentInaccuracy,
                currentInaccuracy
            );

            bulletRotation *= Quaternion.Euler(randomPitch, randomJaw, 0f);

            AudioManager.Instance.PlaySFX(shootingSFX, 0.5F);

            GameObject b = Instantiate(bulletPrefab, bulletSpawnPoint.position, bulletRotation);
            Bullet bullet = b.GetComponent<Bullet>();
            if (bullet != null) bullet.SetOwner(gameObject);

            Instantiate(
                weaponFlash,
                bulletSpawnPoint.position,
                bulletRotation
            );

            lastShootTime = Time.time;
        }
    }
}
