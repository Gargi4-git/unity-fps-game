using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    public float reloadTime = 1f;
    public float fireRate = 0.15f;
    public int magSize = 20;
    public float recoilDistance = 0.1f;
    public float recoilSpeed = 15f;

    public AudioClip shootingSFX;

    public GameObject bullet;
    public Transform bulletSpawnPoint;
    public GameObject weaponFlash;
    public GameObject droppedWeapon;

    private int currentAmmo;
    private bool isReloading = false;
    private float nextTimeToFire = 0f;

    private Quaternion initialRotation;
    private Vector3 initialPosition;
    private Vector3 reloadRotationOffset = new Vector3(66, 50,50);
    // Start is called before the first frame update
    void Start()
    {
        currentAmmo = magSize;
        initialRotation = transform.localRotation;
        initialPosition = transform.localPosition;
    }


    public void Shoot()
    {
        if (isReloading) return;
        if (Time.time < nextTimeToFire) return;

        if (currentAmmo <= 0)
        {
            StartCoroutine(Reload());
            return;
        }

        if (bullet == null)
        {
            Debug.LogError("Rifle bullet prefab is not assigned!", this);
            return;
        }

        if (bulletSpawnPoint == null)
        {
            Debug.LogError("Bullet Spawn Point is not assigned!", this);
            return;
        }

        nextTimeToFire = Time.time + fireRate;
        currentAmmo--;
        Quaternion adjustedRotation = bulletSpawnPoint.rotation * Quaternion.Euler(-3f, -2f, 0f);
        AudioManager.Instance.PlaySFX(shootingSFX, 0.25f);
        Debug.Log("Bullet prefab: " + bullet.name);
        Debug.Log("Spawn point: " + bulletSpawnPoint.position);
        Debug.Log("Spawn rotation: " + bulletSpawnPoint.rotation.eulerAngles);


        GameObject spawnedBullet = Instantiate(
            bullet,
            bulletSpawnPoint.position,
            adjustedRotation
        );
        Bullet b = spawnedBullet.GetComponent<Bullet>();
        if (b != null) b.SetOwner(transform.root.gameObject);
        Debug.DrawRay(spawnedBullet.transform.position, spawnedBullet.transform.forward * 3f, Color.red, 3f);

        Debug.Log("Spawned bullet: " + spawnedBullet.name);


        if (weaponFlash != null)
        {
            GameObject flash = Instantiate(
                weaponFlash,
                bulletSpawnPoint.position,
                bulletSpawnPoint.rotation
            );

            flash.SetActive(true);
            Destroy(flash, 0.15f);
        }
        else
        {
            Debug.LogWarning("Weapon Flash prefab is not assigned!", this);
        }

    }


    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator Reload()
    {
        isReloading = true;
        Quaternion targetRotation = Quaternion.Euler(initialRotation.eulerAngles + reloadRotationOffset);
        float halfReload = reloadTime / 2f;
        float t = 0f;

        while (t < halfReload)
        {
            t += Time.deltaTime;
            transform.localRotation = Quaternion.Lerp(
                     initialRotation,
                      targetRotation,
                      t / halfReload
                    );
            yield return null;

        }
        t = 0f;
        while (t < halfReload)
        {
            t += Time.deltaTime;
            transform.localRotation = Quaternion.Lerp(
    targetRotation,
    initialRotation,
    t / halfReload
);
            yield return null;
        }

        currentAmmo = magSize;
        isReloading = false;
    }

    public void TryReload()
    {
        if (isReloading) return;
        if (currentAmmo == magSize) return;

        StartCoroutine(Reload());
    }

    private IEnumerator Recoil()
    {
        Vector3 recoilTarget = initialPosition + new Vector3(0, 0, 0);
        float t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime * recoilSpeed;
            transform.localPosition = Vector3.Lerp(
                     initialPosition,
                      recoilTarget,
                      t
                    );
            yield return null;

        }
        t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime * recoilSpeed;
            transform.localPosition = Vector3.Lerp(
                 recoilTarget,
                     initialPosition,
                      t
                    );
            yield return null;

        }
        transform.localPosition = initialPosition;
    }


    public void Drop()
    {
        if (droppedWeapon == null)
        {
            Debug.LogError("Dropped Weapon Prefab is not assigned!", this);
            return;
        }

        // Create the dropped weapon in the scene.
        GameObject dropped = Instantiate(
            droppedWeapon,
            transform.position,
            transform.rotation
        );

        // Ensure the dropped weapon can be picked up.
        if (dropped.GetComponent<PickUp>() == null)
        {
            Debug.LogWarning(
                "Dropped weapon prefab needs a PickUp component!",
                dropped
            );
        }

        // Remove this equipped weapon instance.
        Destroy(gameObject);
    }

}


