
using UnityEngine;

public class PickUp : MonoBehaviour
{
    public Material highlightedMaterial;
    public GameObject weaponPrefab;
    public float lookRange = 3f;

    private PlayerShooting player;
    private Camera playerCamera;

    private Renderer[] renderers;
    private Material[][] originalMaterials;


    private bool isHighlighted;

    private void Start()
    {
        player = FindFirstObjectByType<PlayerShooting>();

        if (player != null)
            playerCamera = player.playerCamera;

        renderers = GetComponentsInChildren<Renderer>(true);
        originalMaterials = new Material[renderers.Length][];

        for (int i = 0; i < renderers.Length; i++)
            originalMaterials[i] = renderers[i].materials;

        if (playerCamera == null)
            Debug.LogError("PickUp: Player camera is missing.", this);

        if (highlightedMaterial == null)
            Debug.LogWarning("PickUp: Assign a highlighted material.", this);
    }

    private void Update()
    {
        if (playerCamera == null || highlightedMaterial == null)
            return;

        Vector3 center = transform.position;
        float distance = Vector3.Distance(
            playerCamera.transform.position, center
        );

        bool shouldHighlight = distance <= lookRange &&
            IsInFrontOfCamera(center);

        if (shouldHighlight != isHighlighted)
        {
            isHighlighted = shouldHighlight;
            SetHighlight(isHighlighted);
        }
    }

    private bool IsInFrontOfCamera(Vector3 target)
    {
        Vector3 direction = target - playerCamera.transform.position;

        return Vector3.Dot(
            playerCamera.transform.forward,
            direction.normalized
        ) > 0.85f;
    }

    private void SetHighlight(bool enable)
    {
        for (int i = 0; i < renderers.Length; i++)
        {
            if (enable)
            {
                Material[] materials = renderers[i].materials;

                for (int j = 0; j < materials.Length; j++)
                    materials[j] = highlightedMaterial;

                renderers[i].materials = materials;
            }
            else
            {
                renderers[i].materials = originalMaterials[i];
            }
        }
    }




    public void OnPickUp()
    {
        if (player == null)
        {
            Debug.LogError("PlayerShooting not found!", this);
            return;
        }

        if (weaponPrefab == null)
        {
            Debug.LogError("Weapon Prefab is not assigned!", this);
            return;
        }

        if (player.gunHolder == null)
        {
            Debug.LogError("Gun Holder is not assigned!", this);
            return;
        }

        // Remove the currently equipped weapon, if any.
        if (player.gun != null)
        {
            Transform oldWeapon = player.gun.transform;

            while (oldWeapon.parent != null &&
                   oldWeapon.parent != player.gunHolder)
            {
                oldWeapon = oldWeapon.parent;
            }

            if (oldWeapon.parent == player.gunHolder)
            {
                Destroy(oldWeapon.gameObject);
            }

            player.gun = null;
        }

        // Equip the weapon being picked up.
        GameObject newWeapon = Instantiate(
            weaponPrefab,
            player.gunHolder
        );

        newWeapon.transform.localPosition = Vector3.zero;
        newWeapon.transform.localRotation = Quaternion.identity;

        Gun newGun = newWeapon.GetComponentInChildren<Gun>(true);

        if (newGun == null)
        {
            Debug.LogError(
                "Equipped weapon prefab has no Gun component!",
                newWeapon
            );

            Destroy(newWeapon);
            return;
        }

        player.gun = newGun;

        Debug.Log("Equipped weapon: " + newWeapon.name);

        // Remove the pickup object from the ground.
        Destroy(gameObject);
    }



}
