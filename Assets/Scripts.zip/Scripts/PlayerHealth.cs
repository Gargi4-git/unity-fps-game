using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public AudioClip hitSFX;
    public int health = 100;
    private bool isDead = false;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("EnemyBullet"))
        {
            Debug.Log("Player hit! Health: " + health);
            DecreaseHealth(10);
        }
    }

    private void DecreaseHealth(int decreaseAmount)
    {
        if (isDead) return;

        health -= decreaseAmount;

        if (health <= 0)
        {
            Die();
            return;
        }

        if (PlayerLook.Instance != null)
            PlayerLook.Instance.AddShake(0.1f, 0.25f);

        if (UIManager.Instance != null)
            UIManager.Instance.InstantiateHitUI();

        if (AudioManager.Instance != null)
            AudioManager.Instance.PlaySFX(hitSFX);
    }

    private void Die()
    {
        isDead = true;
        Debug.Log("PLAYER DIED");
        Time.timeScale = 0f;
    }
}   