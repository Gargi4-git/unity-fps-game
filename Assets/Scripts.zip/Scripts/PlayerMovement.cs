
using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 5f;

    public Transform groundCheck;
    public float groundDistance = 0.4f;
    public LayerMask groundMask;

    private Rigidbody rb;
    private Vector2 moveInput;
    private bool isGrounded;
    private PlayerInput playerInput;

    public AudioClip footStep;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        if (rb == null)
        {
            Debug.LogError("Rigidbody is missing from the Player!");
            enabled = false;
            return;
        }

        

        StartCoroutine(PlayFootStep());

        rb.freezeRotation = true;
    }

    void Update()
    {
        CheckGround();
    }

    void FixedUpdate()
    {
        MovePlayer();
    }

    public void OnJump(InputValue value)
    {
        if (!value.isPressed)
            return;

        if (!isGrounded || rb == null)
            return;

        rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
    }

    public void OnMovement(InputValue value)
    {
        moveInput = value.Get<Vector2>();
    }

    void CheckGround()
    {
        if (groundCheck == null)
        {
            isGrounded = false;
            return;
        }

        isGrounded = Physics.CheckSphere(
            groundCheck.position,
            groundDistance,
            groundMask
        );
    }

    void MovePlayer()
    {
        if (rb == null)
            return;

        Vector3 direction =
            transform.right * moveInput.x +
            transform.forward * moveInput.y;

        direction.Normalize();

        rb.velocity = new Vector3(
            direction.x * moveSpeed,
            rb.velocity.y,
            direction.z * moveSpeed
        );
    }

    IEnumerator PlayFootStep()
    {
        while (true)
        {
            if (rb.velocity.magnitude > 0.1f && isGrounded)
            {
                if (AudioManager.Instance != null && footStep != null)
                {
                    AudioManager.Instance.PlaySFX(footStep);
                }
            }

            yield return new WaitForSeconds(0.5f);
        }
    }
}
