using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
    

public class PlayerShooting : MonoBehaviour
{
    public Gun gun;
    public Transform gunHolder;
    private bool isHoldingShoot = false;
    public Camera playerCamera;
    public float pickupRange = 5f;

    void OnShoot()
    {
        isHoldingShoot = true;
    }

    void OnShootRelease()
    {
        isHoldingShoot = false;
    }
    public void OnShoot(InputValue value)
    {
        isHoldingShoot = value.isPressed;
    }

    void OnReload()
    {
        if(gun!= null)
        {
            gun.TryReload();
        }
    }
    // Start is called before the first frame update

    private void Start()
    {
        // Find the actual equipped weapon under Gun Holder.
        if (gunHolder != null)
        {
            Gun equippedGun = gunHolder.GetComponentInChildren<Gun>(true);

            if (equippedGun != null)
            {
                gun = equippedGun;
                Debug.Log("Equipped weapon found: " + gun.name);
            }
            else
            {
                gun = null;
                Debug.LogWarning("No Gun component found under Gun Holder.");
            }
        }
        else
        {
            Debug.LogError("Gun Holder is not assigned!");
        }
    }
    

    // Update is called once per frame
    void Update()
    {
        if (isHoldingShoot && gun != null)
        {
            gun.Shoot();
        }
    }




    public void OnPickUp(InputValue value)
    {
        if (!value.isPressed)
            return;

        if (playerCamera == null)
        {
            Debug.LogError("Player Camera is not assigned!", this);
            return;
        }

        PickUp[] pickups = FindObjectsByType<PickUp>(
            FindObjectsSortMode.None
        );

        PickUp bestPickup = null;
        float bestDot = 0.6f;
        float bestDistance = float.MaxValue;

        foreach (PickUp pickup in pickups)
        {
            if (pickup == null || !pickup.isActiveAndEnabled)
                continue;

            Vector3 direction =
                pickup.transform.position - playerCamera.transform.position;

            float distance = direction.magnitude;

            if (distance > pickupRange || distance <= 0.01f)
                continue;

            float dot = Vector3.Dot(
                playerCamera.transform.forward,
                direction.normalized
            );

            if (dot < 0.6f)
                continue;

            if (bestPickup == null ||
                dot > bestDot ||
                (Mathf.Approximately(dot, bestDot) &&
                 distance < bestDistance))
            {
                bestPickup = pickup;
                bestDot = dot;
                bestDistance = distance;
            }
        }

        if (bestPickup != null)
        {
            Debug.Log("Selected pickup: " + bestPickup.name);
            bestPickup.OnPickUp();
        }
        else
        {
            Debug.Log("No pickup in range. Check distance and camera aim.");
        }
    }
    public void OnDrop(InputValue value)
    {
        if (value.isPressed && gun != null)
        {
            gun.Drop();
            gun = null;
        }
    }



}
