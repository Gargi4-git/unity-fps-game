using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;
    public GameObject HitUI;

    private void Awake()
    {
        Instance = this;
    }

    public void InstantiateHitUI()
    {
        Instantiate(HitUI, transform);
    }
}
